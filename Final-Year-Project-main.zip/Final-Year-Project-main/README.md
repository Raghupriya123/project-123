# Firelion-Industries-Project
 It is a promotional business website developed for ‘Firelion Industries’. For developing this website we had used HTML 5, CSS 3 and JavaScript as a front end and Firebase as a backend.
